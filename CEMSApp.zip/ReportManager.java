import java.util.*;
import java.io.*;

public class ReportManager {
    public void exportToCSV(List<Event> events, String filename) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(filename));
        pw.println("ID,Name,Date,Venue,Description");
        for (Event e : events) {
            pw.printf("%s,%s,%s,%s,%s\n", e.getId(), e.getName(), e.getDate(), e.getVenue(), e.getDescription());
        }
        pw.close();
    }

    public void exportToTxt(List<Event> events, String filename) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(filename));
        for (Event e : events) {
            pw.printf("Event ID: %s\nName: %s\nDate: %s\nVenue: %s\nDescription: %s\n\n",
                e.getId(), e.getName(), e.getDate(), e.getVenue(), e.getDescription());
        }
        pw.close();
    }
}
