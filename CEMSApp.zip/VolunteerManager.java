import java.util.*;

public class VolunteerManager {
    private List<Volunteer> volunteers = new ArrayList<>();

    public void addVolunteer(Volunteer v) { volunteers.add(v); }

    public List<Volunteer> getAllVolunteers() {
        return volunteers;
    }
}
