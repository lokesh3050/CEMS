import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class CEMSApp {
    private EventManager eventManager = new EventManager();
    private VolunteerManager volunteerManager = new VolunteerManager();
    private ReportManager reportManager = new ReportManager();

    private DefaultTableModel eventTableModel;
    private DefaultTableModel volunteerTableModel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CEMSApp().showLoginScreen());
    }

    private void showLoginScreen() {
        JFrame loginFrame = new JFrame("Login - College Event Management System");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(350, 200);
        loginFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();

        panel.add(new JLabel("Username:")); panel.add(userField);
        panel.add(new JLabel("Password:")); panel.add(passField);

        JButton loginBtn = new JButton("Login");
        panel.add(new JLabel()); panel.add(loginBtn);

        loginBtn.addActionListener(e -> {
            String user = userField.getText();
            String pass = new String(passField.getPassword());
            if ((user.equals("admin") && pass.equals("admin123")) ||
                (user.equals("user") && pass.equals("user123"))) {
                loginFrame.dispose();
                createGUI();
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Invalid credentials");
            }
        });

        loginFrame.add(panel);
        loginFrame.setVisible(true);
    }

    private void createGUI() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        JFrame frame = new JFrame("College Event Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 16));

        // Events Tab
        JPanel eventPanel = new JPanel(new BorderLayout(10, 10));
        eventPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField dateField = new JTextField();
        JTextField venueField = new JTextField();
        JTextField descField = new JTextField();

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
        formPanel.add(new JLabel("Event ID:")); formPanel.add(idField);
        formPanel.add(new JLabel("Name:")); formPanel.add(nameField);
        formPanel.add(new JLabel("Date (YYYY-MM-DD):")); formPanel.add(dateField);
        formPanel.add(new JLabel("Venue:")); formPanel.add(venueField);
        formPanel.add(new JLabel("Description:")); formPanel.add(descField);

        JButton addEventBtn = new JButton("Add Event");
        addEventBtn.addActionListener(e -> {
            Event ev = new Event(idField.getText(), nameField.getText(), dateField.getText(), venueField.getText(), descField.getText());
            eventManager.addEvent(ev);
            eventTableModel.addRow(new Object[]{ev.getId(), ev.getName(), ev.getDate(), ev.getVenue(), ev.getDescription()});
            idField.setText(""); nameField.setText(""); dateField.setText(""); venueField.setText(""); descField.setText("");
        });

        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.add(formPanel);
        formContainer.add(Box.createVerticalStrut(10));
        formContainer.add(addEventBtn);

        eventPanel.add(formContainer, BorderLayout.NORTH);

        eventTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Venue", "Description"}, 0);
        JTable eventTable = new JTable(eventTableModel);
        eventTable.setRowHeight(28);
        eventPanel.add(new JScrollPane(eventTable), BorderLayout.CENTER);
        tabs.addTab("\uD83D\uDCC5 Events", eventPanel);

        // Volunteers Tab
        JPanel volPanel = new JPanel(new BorderLayout(10, 10));
        volPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTextField vid = new JTextField();
        JTextField vname = new JTextField();
        JTextField vrole = new JTextField();

        JPanel vForm = new JPanel(new GridLayout(3, 2, 8, 8));
        vForm.add(new JLabel("Volunteer ID:")); vForm.add(vid);
        vForm.add(new JLabel("Name:")); vForm.add(vname);
        vForm.add(new JLabel("Role:")); vForm.add(vrole);

        JButton addVolBtn = new JButton("Add Volunteer");
        addVolBtn.addActionListener(e -> {
            Volunteer vol = new Volunteer(vid.getText(), vname.getText(), vrole.getText());
            volunteerManager.addVolunteer(vol);
            volunteerTableModel.addRow(new Object[]{vol.getId(), vol.getName(), vol.getRole()});
            vid.setText(""); vname.setText(""); vrole.setText("");
        });

        JPanel vContainer = new JPanel();
        vContainer.setLayout(new BoxLayout(vContainer, BoxLayout.Y_AXIS));
        vContainer.add(vForm);
        vContainer.add(Box.createVerticalStrut(10));
        vContainer.add(addVolBtn);

        volPanel.add(vContainer, BorderLayout.NORTH);

        volunteerTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Role"}, 0);
        JTable volTable = new JTable(volunteerTableModel);
        volTable.setRowHeight(28);
        volPanel.add(new JScrollPane(volTable), BorderLayout.CENTER);
        tabs.addTab("\uD83E\uDD1D Volunteers", volPanel);

        // Reports Tab
        JPanel reportPanel = new JPanel();
        JButton exportCSV = new JButton("Export Events to CSV");
        JButton exportTXT = new JButton("Export Events to TXT");

        exportCSV.addActionListener(e -> {
            try {
                reportManager.exportToCSV(eventManager.getAllEvents(), "events.csv");
                JOptionPane.showMessageDialog(frame, "Exported to events.csv");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Export failed");
            }
        });

        exportTXT.addActionListener(e -> {
            try {
                reportManager.exportToTxt(eventManager.getAllEvents(), "events.txt");
                JOptionPane.showMessageDialog(frame, "Exported to events.txt");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Export failed");
            }
        });

        reportPanel.add(exportCSV);
        reportPanel.add(exportTXT);
        tabs.addTab("\uD83D\uDCC4 Reports", reportPanel);

        frame.add(tabs);
        frame.setVisible(true);
    }
} 

// Create supporting classes: Event, Volunteer, EventManager, VolunteerManager, ReportManager separately







// import javax.swing.*; //GUI Components like JFrame, JButton, etc
// import javax.swing.border.EmptyBorder; // To add padding/margin around panels (used for neat UI spacing)
// import javax.swing.table.DefaultTableModel; // To manage data in JTable (adding/removing/searching rows)
// import java.awt.*; // Core AWT classes for layouts, fonts, colors, etc.
// import java.awt.event.*; // To handle events like button clicks, mouse movement, etc.
// import java.text.SimpleDateFormat; // To format date values 
// import java.util.ArrayList; // To store and manage list of Events/Volunteers dynamically
// import java.util.List; // List interface used as a type reference for ArrayList
// import java.util.Date; // To represent and work with date values (event date)
// import java.io.*; // For file input/output

// public class CEMSApp {
//     private EventManager eventManager = new EventManager(); // Manages list of Events (Add/Delete)
//     private VolunteerManager volunteerManager = new VolunteerManager();
//     private ReportManager reportManager = new ReportManager(); // Used to export data as CSV or TXT

//     private DefaultTableModel eventTableModel; // Holds data shown in Events table
//     private DefaultTableModel volunteerTableModel;

//     public static void main(String[] args) {
//         SwingUtilities.invokeLater(() -> new CEMSApp().showLoginScreen()); // Launch GUI on Swing thread
//     }

//     private void showLoginScreen() {
//         JFrame loginFrame = new JFrame("Login - College Event Management System"); // Window Title
//         loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exit when closed
//         loginFrame.setSize(350, 200); // Window dimensions
//         loginFrame.setLocationRelativeTo(null); // Center the window

//         JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
//         panel.setBorder(new EmptyBorder(20, 20, 20, 20));

//         JTextField userField = new JTextField(); // Input for username
//         JPasswordField passField = new JPasswordField();

//         panel.add(new JLabel("Username:")); panel.add(userField);
//         panel.add(new JLabel("Password:")); panel.add(passField);

//         JButton loginBtn = new JButton("Login"); // Create login button
//         panel.add(new JLabel()); panel.add(loginBtn);

//         loginBtn.addActionListener(e -> {
//             String user = userField.getText(); // Get username input
//             String pass = new String(passField.getPassword());
//             if ((user.equals("admin") && pass.equals("admin123")) ||
//                 (user.equals("user") && pass.equals("user123"))) {
//                 loginFrame.dispose(); // Close login window
//                 createGUI(); // Open main application
//             } else {
//                 JOptionPane.showMessageDialog(loginFrame, "Invalid credentials");
//             }
//         });

//         loginFrame.add(panel);
//         loginFrame.setVisible(true); // Show the window
//     }

//     private void createGUI() {
//         try {
//             UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
//         } catch (Exception ignored) {}

//         JFrame frame = new JFrame("College Event Management System");
//         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         frame.setSize(1000, 700);
//         frame.setLocationRelativeTo(null);

//         JTabbedPane tabs = new JTabbedPane();
//         tabs.setFont(new Font("Segoe UI", Font.BOLD, 16));

//         // --- Events Tab ---
//         JPanel eventPanel = new JPanel(new BorderLayout(10, 10));
//         eventPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

//         JTextField idField = new JTextField();
//         JTextField nameField = new JTextField();
//         JTextField dateField = new JTextField();
//         JTextField venueField = new JTextField();
//         JTextField descField = new JTextField();

//         JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
//         formPanel.add(new JLabel("Event ID:")); formPanel.add(idField);
//         formPanel.add(new JLabel("Name:")); formPanel.add(nameField);
//         formPanel.add(new JLabel("Date (YYYY-MM-DD):")); formPanel.add(dateField);
//         formPanel.add(new JLabel("Venue:")); formPanel.add(venueField);
//         formPanel.add(new JLabel("Description:")); formPanel.add(descField);

//         eventPanel.add(formPanel, BorderLayout.NORTH);

//         eventTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Venue", "Description"}, 0);
//         JTable eventTable = new JTable(eventTableModel);
//         eventTable.setRowHeight(28);
//         eventPanel.add(new JScrollPane(eventTable), BorderLayout.CENTER);

//         JButton addEventBtn = new JButton("Add Event");
//         addEventBtn.addActionListener(e -> {
//             Event ev = new Event(idField.getText(), nameField.getText(), dateField.getText(), venueField.getText(), descField.getText());
//             eventManager.addEvent(ev);
//             eventTableModel.addRow(new Object[]{ev.getId(), ev.getName(), ev.getDate(), ev.getVenue(), ev.getDescription()});
//         });
//         eventPanel.add(addEventBtn, BorderLayout.SOUTH);
//         tabs.addTab("📅 Events", eventPanel);

//         // --- Volunteers Tab ---
//         JPanel volPanel = new JPanel(new BorderLayout(10, 10));
//         volPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

//         JTextField vid = new JTextField();
//         JTextField vname = new JTextField();
//         JTextField vrole = new JTextField();

//         JPanel vForm = new JPanel(new GridLayout(3, 2, 8, 8));
//         vForm.add(new JLabel("Volunteer ID:")); vForm.add(vid);
//         vForm.add(new JLabel("Name:")); vForm.add(vname);
//         vForm.add(new JLabel("Role:")); vForm.add(vrole);

//         volPanel.add(vForm, BorderLayout.NORTH);

//         volunteerTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Role"}, 0);
//         JTable volTable = new JTable(volunteerTableModel);
//         volTable.setRowHeight(28);
//         volPanel.add(new JScrollPane(volTable), BorderLayout.CENTER);

//         JButton addVolBtn = new JButton("Add Volunteer");
//         addVolBtn.addActionListener(e -> {
//             Volunteer vol = new Volunteer(vid.getText(), vname.getText(), vrole.getText());
//             volunteerManager.addVolunteer(vol);
//             volunteerTableModel.addRow(new Object[]{vol.getId(), vol.getName(), vol.getRole()});
//         });
//         volPanel.add(addVolBtn, BorderLayout.SOUTH);
//         tabs.addTab("🤝 Volunteers", volPanel);

//         // --- Reports Tab ---
//         JPanel reportPanel = new JPanel();
//         JButton exportCSV = new JButton("Export Events to CSV");
//         JButton exportTXT = new JButton("Export Events to TXT");

//         exportCSV.addActionListener(e -> {
//             try {
//                 reportManager.exportToCSV(eventManager.getAllEvents(), "events.csv");
//                 JOptionPane.showMessageDialog(frame, "Exported to events.csv");
//             } catch (IOException ex) {
//                 JOptionPane.showMessageDialog(frame, "Export failed");
//             }
//         });

//         exportTXT.addActionListener(e -> {
//             try {
//                 reportManager.exportToTxt(eventManager.getAllEvents(), "events.txt");
//                 JOptionPane.showMessageDialog(frame, "Exported to events.txt");
//             } catch (IOException ex) {
//                 JOptionPane.showMessageDialog(frame, "Export failed");
//             }
//         });

//         reportPanel.add(exportCSV);
//         reportPanel.add(exportTXT);
//         tabs.addTab("📤 Reports", reportPanel);

//         frame.add(tabs);
//         frame.setVisible(true);
//     }
// }
