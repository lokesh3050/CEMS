import java.util.*;

public class EventManager {
    private List<Event> events = new ArrayList<>();

    public void addEvent(Event e) { events.add(e); }

    public void removeEventById(String id) {
        events.removeIf(e -> e.getId().equals(id));
    }

    public List<Event> getAllEvents() {
        return events;
    }
}
